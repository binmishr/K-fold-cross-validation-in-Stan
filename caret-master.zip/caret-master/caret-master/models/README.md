`models` directory
=========


These files define the code for the specific model.

The `files` directory contains files for each model. In the package, this data is bundled into a list object.

`parseModels.R` will source the models and create the list object that can be added to the package.



	