#' Efficient LOO-CV and WAIC for Bayesian models
#'
#' @docType package
#' @name loo-package
#'
#' @importFrom stats sd var quantile setNames weights rnorm qnorm
#' @importFrom matrixStats logSumExp colLogSumExps colSums2 colVars colMaxs
#'
#' @description
#' \if{html}{
#'   \figure{stanlogo.png}{options: width="50px" alt="mc-stan.org"}
#' }
#' *Stan Development Team*
#'
#' This package implements the methods described in Vehtari, Gelman, and
#' Gabry (2017), Vehtari, Simpson, Gelman, Yao, and Gabry (2019), and
#' Yao et al. (2018). To get started see the **loo** package
#' [vignettes](https://mc-stan.org/loo/articles/index.html), the
#' [loo()] function for efficient approximate leave-one-out
#' cross-validation (LOO-CV), the [psis()] function for the Pareto
#' smoothed importance sampling (PSIS) algorithm, or
#' [loo_model_weights()] for an implementation of Bayesian stacking of
#' predictive distributions from multiple models.
#'
#'
#' @details Leave-one-out cross-validation (LOO-CV) and the widely applicable
#'   information criterion (WAIC) are methods for estimating pointwise
#'   out-of-sample prediction accuracy from a fitted Bayesian model using the
#'   log-likelihood evaluated at the posterior simulations of the parameter
#'   values. LOO-CV and WAIC have various advantages over simpler estimates of
#'   predictive error such as AIC and DIC but are less used in practice because
#'   they involve additional computational steps. This package implements the
#'   fast and stable computations for approximate LOO-CV laid out in Vehtari,
#'   Gelman, and Gabry (2017a). From existing posterior simulation draws, we
#'   compute LOO-CV using Pareto smoothed importance sampling (PSIS; Vehtari,
#'   Simpson, Gelman, Yao, and Gabry, 2019), a new procedure for stabilizing
#'   and diagnosing importance weights. As a byproduct of our calculations,
#'   we also obtain approximate standard errors for estimated predictive
#'   errors and for comparing of predictive errors between two models.
#'
#'   We recommend PSIS-LOO-CV instead of WAIC, because PSIS provides useful
#'   diagnostics and effective sample size and Monte Carlo standard error
#'   estimates.
#'
#'
#' @template loo-and-psis-references
#' @template stacking-references
#' @template loo-large-data-references
#'

#'
NULL
