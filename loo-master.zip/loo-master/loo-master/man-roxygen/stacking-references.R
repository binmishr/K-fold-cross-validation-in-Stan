#'   stacking to average Bayesian predictive distributions.
#'   *Bayesian Analysis*, advance publication,  doi:10.1214/17-BA1091.
#'   ([online](https://projecteuclid.org/euclid.ba/1516093227)).
#'
