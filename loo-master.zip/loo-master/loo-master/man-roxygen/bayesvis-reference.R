#' @references 
#'   ([journal version](https://rss.onlinelibrary.wiley.com/doi/full/10.1111/rssa.12378),
#'    [preprint arXiv:1709.01449](https://arxiv.org/abs/1709.01449),

