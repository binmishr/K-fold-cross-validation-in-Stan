#' @references
#' Leave-One-Out Cross-Validation for Large Data.
#' In _International Conference on Machine Learning_
#'
#' Leave-One-Out Cross-Validation for Model Comparison in Large Data.
#'
