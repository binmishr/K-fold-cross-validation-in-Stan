#' @describeIn <%= fn %> A vector of length \eqn{S} (posterior sample size).
