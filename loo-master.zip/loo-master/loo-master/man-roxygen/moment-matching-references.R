#' @references
#' Implicitly Adaptive Importance Sampling.
#' [preprint arXiv:1906.08850](https://arxiv.org/abs/1906.08850)
#'
