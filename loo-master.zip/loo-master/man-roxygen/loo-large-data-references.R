#' @references
#' Magnusson, M., Riis Andersen, M., Jonasson, J. and Vehtari, A. (2019).
#' Leave-One-Out Cross-Validation for Large Data.
#' In _International Conference on Machine Learning_
#'
#' Magnusson, M., Riis Andersen, M., Jonasson, J. and Vehtari, A. (2019).
#' Leave-One-Out Cross-Validation for Model Comparison in Large Data.
#'
