#' @note This function is primarily intended for internal use, but is exported
#'   so that users can call it directly if interested in PSIS for purposes other
#'   than LOO-CV.
