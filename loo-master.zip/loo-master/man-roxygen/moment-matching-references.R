#' @references
#' Paananen, T., Piironen, J., Buerkner, P.-C., Vehtari, A. (2020).
#' Implicitly Adaptive Importance Sampling.
#' [preprint arXiv:1906.08850](https://arxiv.org/abs/1906.08850)
#'
